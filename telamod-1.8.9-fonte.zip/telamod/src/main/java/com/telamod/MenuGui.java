package com.telamod;

import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class MenuGui extends GuiScreen {
    private GuiButton bStretch, bFps, bCps, bKeys;

    @Override
    public void initGui() {
        int cx = width / 2, cy = height / 2;
        buttonList.clear();
        buttonList.add(bStretch = new GuiButton(0, cx - 100, cy - 60, 200, 20, ""));
        buttonList.add(bFps = new GuiButton(1, cx - 100, cy - 36, 200, 20, ""));
        buttonList.add(bCps = new GuiButton(2, cx - 100, cy - 12, 200, 20, ""));
        buttonList.add(bKeys = new GuiButton(3, cx - 100, cy + 12, 200, 20, ""));
        buttonList.add(new GuiButton(4, cx - 100, cy + 36, 98, 20, "Largura -"));
        buttonList.add(new GuiButton(5, cx + 2, cy + 36, 98, 20, "Largura +"));
        buttonList.add(new GuiButton(6, cx - 100, cy + 64, 200, 20, "Fechar"));
        refresh();
    }

    private String onOff(boolean b) { return b ? "LIGADO" : "DESLIGADO"; }

    private void refresh() {
        bStretch.displayString = "Tela esticada: " + onOff(TelaMod.stretch);
        bFps.displayString = "FPS: " + onOff(TelaMod.showFps);
        bCps.displayString = "CPS: " + onOff(TelaMod.showCps);
        bKeys.displayString = "Keystrokes: " + onOff(TelaMod.showKeys);
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        switch (b.id) {
            case 0: TelaMod.stretch = !TelaMod.stretch; break;
            case 1: TelaMod.showFps = !TelaMod.showFps; break;
            case 2: TelaMod.showCps = !TelaMod.showCps; break;
            case 3: TelaMod.showKeys = !TelaMod.showKeys; break;
            case 4: TelaMod.factor = Math.max(0.3f, TelaMod.factor - 0.05f); break;
            case 5: TelaMod.factor = Math.min(1.5f, TelaMod.factor + 0.05f); break;
            case 6: mc.displayGuiScreen(null); return;
        }
        refresh();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "TelaMod", width / 2, height / 2 - 90, 0xFFFFFF);
        drawCenteredString(fontRendererObj, "Largura da imagem: " + Math.round(TelaMod.factor * 100) + "%",
                width / 2, height / 2 + 24 + 36 + 22, 0xAAAAAA);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
