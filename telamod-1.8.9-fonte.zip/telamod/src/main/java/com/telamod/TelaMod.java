package com.telamod;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = TelaMod.MODID, name = "TelaMod", version = "1.0",
        clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class TelaMod {
    public static final String MODID = "telamod";

    public static boolean stretch = true, showFps = true, showCps = true, showKeys = true;
    public static float factor = 0.75f; // largura virtual (75% = imagem esticada)

    private static KeyBinding openKey;
    private final Minecraft mc = Minecraft.getMinecraft();
    private final List<Long> left = new ArrayList<Long>();
    private final List<Long> right = new ArrayList<Long>();
    private int origW = -1;
    private boolean worldDone = false;

    @EventHandler
    public void init(FMLInitializationEvent e) {
        openKey = new KeyBinding("Abrir menu", Keyboard.KEY_J, "TelaMod");
        ClientRegistry.registerKeyBinding(openKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && openKey.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new MenuGui());
        }
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate) return;
        long now = System.currentTimeMillis();
        if (e.button == 0) left.add(now);
        else if (e.button == 1) right.add(now);
    }

    // ---- Tela esticada: muda a proporção só durante o render do mundo ----
    @SubscribeEvent
    public void onFov(EntityViewRenderEvent.FOVModifier e) {
        if (stretch && !worldDone && origW < 0 && mc.theWorld != null) {
            origW = mc.displayWidth;
            mc.displayWidth = Math.max(1, (int) (origW * factor));
        }
    }

    @SubscribeEvent
    public void onWorldLast(RenderWorldLastEvent e) {
        restore();
        worldDone = true;
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) worldDone = false;
        restore();
    }

    private void restore() {
        if (origW >= 0) {
            mc.displayWidth = origW;
            origW = -1;
        }
    }

    // ---- HUD ----
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.TEXT) return;
        FontRenderer fr = mc.fontRendererObj;
        int y = 4;
        if (showFps) {
            fr.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), 4, y, 0xFFFFFF);
            y += 12;
        }
        if (showCps) {
            fr.drawStringWithShadow("CPS: " + cps(left) + " | " + cps(right), 4, y, 0xFFFFFF);
            y += 12;
        }
        if (showKeys) {
            y += 4;
            int x = 4;
            key(fr, "W", x + 22, y, 20, mc.gameSettings.keyBindForward.isKeyDown());
            key(fr, "A", x, y + 22, 20, mc.gameSettings.keyBindLeft.isKeyDown());
            key(fr, "S", x + 22, y + 22, 20, mc.gameSettings.keyBindBack.isKeyDown());
            key(fr, "D", x + 44, y + 22, 20, mc.gameSettings.keyBindRight.isKeyDown());
            key(fr, "LMB", x, y + 44, 31, mc.gameSettings.keyBindAttack.isKeyDown());
            key(fr, "RMB", x + 33, y + 44, 31, mc.gameSettings.keyBindUseItem.isKeyDown());
        }
    }

    private int cps(List<Long> list) {
        long limit = System.currentTimeMillis() - 1000;
        while (!list.isEmpty() && list.get(0) < limit) list.remove(0);
        return list.size();
    }

    private void key(FontRenderer fr, String label, int x, int y, int w, boolean down) {
        Gui.drawRect(x, y, x + w, y + 20, down ? 0xAAFFFFFF : 0x80000000);
        fr.drawString(label, x + (w - fr.getStringWidth(label)) / 2, y + 6, down ? 0x000000 : 0xFFFFFF);
    }
}
